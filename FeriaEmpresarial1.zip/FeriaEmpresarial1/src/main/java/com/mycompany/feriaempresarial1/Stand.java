/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
public class Stand {
    private int id;
    private String nombreExpositor;
    private String categoria;
    private double costo;
    private static int contadorId = 1;

    public Stand(String nombreExpositor, String categoria, double costo) {
        this.id = contadorId++;
        this.nombreExpositor = nombreExpositor;
        this.categoria = categoria;
        this.costo = costo;
    }

    public int getId() {
        return id;
    }

    public String getNombreExpositor() {
        return nombreExpositor;
    }

    public void setNombreExpositor(String nombreExpositor) {
        this.nombreExpositor = nombreExpositor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public double getCosto(){
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public String obtenerDetalles() {
        return "ID: " + id + 
               " | Expositor: " + nombreExpositor + 
               " | Categoria: " + categoria + 
               " | Costo: $" + String.format("%,.2f", costo);
    }
}
