/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.util.Scanner;

public class FeriaEmpresarial1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Feria miFeria = new Feria("Feria de Innovacion 2025"); 
        
        System.out.println("Bienvenido al sistema de gestion de '" + miFeria.getNombre() + "'!");

        boolean salir = false;
        
        while (!salir) {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Registrar un nuevo Stand");
            System.out.println("2. Buscar Stand por ID");
            System.out.println("3. Listar todos los Stands");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");

            try {
                int opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1:
                        System.out.println("\n--- Registro de Nuevo Stand ---");
                        System.out.print("Nombre del expositor: ");
                        String expositor = teclado.nextLine();
                        System.out.print("Categoria (Ej: Tecnologia, Alimentos): ");
                        String categoria = teclado.nextLine();
                        System.out.print("Costo de alquiler: ");
                        double costo = Double.parseDouble(teclado.nextLine());

                        miFeria.agregarStand(new Stand(expositor, categoria, costo));
                        break;
                    case 2:
                        System.out.println("\n--- Busqueda de Stand ---");
                        System.out.print("Ingrese el ID del stand a buscar: ");
                        int idBusqueda = Integer.parseInt(teclado.nextLine());
                        
                        Stand standEncontrado = miFeria.buscarStandPorId(idBusqueda);
                        
                        if (standEncontrado != null) {
                            System.out.println("Stand encontrado:");
                            System.out.println(standEncontrado.obtenerDetalles());
                        } else {
                            System.out.println("No se encontro ningun stand con el ID " + idBusqueda + ".");
                        }
                        break;
                    case 3:
                        miFeria.listarTodosLosStands();
                        break;
                    case 4:
                        salir = true;
                        System.out.println("\nGracias por usar el sistema. Hasta pronto!");
                        break;
                    default:
                        System.out.println("Opcion no valida. Por favor, intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe ingresar un numero valido.");
            }
        }
        teclado.close();
    }
}
