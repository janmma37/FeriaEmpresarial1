package com.mycompany.feriaempresarial1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author juans
 */
import java.util.ArrayList;
import java.util.List;

public class Feria {
    private String nombre;
    private List<Stand> stands;

    public Feria(String nombre) {
        this.nombre = nombre;
        this.stands = new ArrayList<>();
    }

    public void agregarStand(Stand stand) {
        this.stands.add(stand);
        System.out.println("Stand para '" + stand.getNombreExpositor() + "' agregado exitosamente.");
    }

    public Stand buscarStandPorId(int id) {
        for (Stand stand : stands) {
            if (stand.getId() == id) {
                return stand;
            }
        }
        return null;
    }

    public void listarTodosLosStands() {
        System.out.println("\n--- Lista de Stands en '" + this.nombre + "' ---");
        if (stands.isEmpty()) {
            System.out.println("No hay stands registrados todavia.");
        } else {
            for (Stand stand : stands) {
                System.out.println(stand.obtenerDetalles());
            }
        }
        System.out.println("----------------------------------------------");
    }
    
    public String getNombre() {
        return nombre;
    }
}
